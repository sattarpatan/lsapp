-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 08, 2019 at 01:59 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `meetings_erp`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblactivitylog`
--

CREATE TABLE `tblactivitylog` (
  `id` int(11) NOT NULL,
  `description` mediumtext NOT NULL,
  `date` datetime NOT NULL,
  `staffid` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblactivitylog`
--

INSERT INTO `tblactivitylog` (`id`, `description`, `date`, `staffid`) VALUES
(1, 'Failed Login Attempt [Email:employee@gmail.com, Is Staff Member:Yes, IP:::1]', '2019-02-04 08:53:03', NULL),
(2, 'New Staff Member Added [ID: 6, ram prasad]', '2019-02-05 08:35:56', 'Abdul Sattar'),
(3, 'New Staff Member Added [ID: 7, ram prads]', '2019-02-05 08:36:52', 'Abdul Sattar'),
(4, 'New Staff Member Added [ID: 8, xxxx ddddd]', '2019-02-05 08:47:43', 'Abdul Sattar'),
(5, 'Role Updated [ID: 2.Employee]', '2019-02-05 10:38:38', 'Abdul Sattar'),
(6, 'Role Updated [ID: 2.Employee]', '2019-02-05 10:38:48', 'Abdul Sattar'),
(7, 'Role Updated [ID: 2.Employee]', '2019-02-05 10:38:53', 'Abdul Sattar'),
(8, 'Role Updated [ID: 2.Employee]', '2019-02-05 10:39:12', 'Abdul Sattar'),
(9, 'Role Updated [ID: 2.Employee]', '2019-02-05 10:39:42', 'Abdul Sattar'),
(10, 'Role Updated [ID: 2.Employee]', '2019-02-05 10:39:53', 'Abdul Sattar'),
(11, 'Role Updated [ID: 2.Employee]', '2019-02-05 10:40:04', 'Abdul Sattar'),
(12, 'Role Updated [ID: 1.Super Admin]', '2019-02-05 10:51:20', 'Abdul Sattar'),
(13, 'Role Updated [ID: 2.Employee]', '2019-02-05 10:51:47', 'Abdul Sattar'),
(14, 'Role Updated [ID: 2.Employee]', '2019-02-05 10:53:42', 'Abdul Sattar'),
(15, 'Staff Member Updated [ID: 8,  ]', '2019-02-05 13:15:42', 'Abdul Sattar'),
(16, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-05 14:57:45', 'Abdul Sattar'),
(17, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-05 14:58:32', 'Abdul Sattar'),
(18, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-05 15:02:08', 'Abdul Sattar'),
(19, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-05 15:02:22', 'Abdul Sattar'),
(20, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-05 15:02:49', 'Abdul Sattar'),
(21, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 06:43:02', 'Abdul Sattar'),
(22, 'Staff Member Updated [ID: 2, Employee1 Employee1]', '2019-02-06 06:44:47', 'Abdul Sattar'),
(23, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 08:08:28', 'Abdul Sattar'),
(24, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 08:08:29', 'Abdul Sattar'),
(25, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 08:08:30', 'Abdul Sattar'),
(26, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 08:08:31', 'Abdul Sattar'),
(27, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 08:08:32', 'Abdul Sattar'),
(28, 'Role Updated [ID: 2.Employee]', '2019-02-06 08:33:02', 'Abdul Sattar'),
(29, 'Role Updated [ID: 2.Employee]', '2019-02-06 08:33:05', 'Abdul Sattar'),
(30, 'Staff Member Updated [ID: 4, Abdul Sattar]', '2019-02-06 08:33:58', 'Abdul Sattar'),
(31, 'Staff Member Updated [ID: 4, Abdul Sattar]', '2019-02-06 08:33:59', 'Abdul Sattar'),
(32, 'Staff Member Updated [ID: 4, Abdul Sattar]', '2019-02-06 08:34:04', 'Abdul Sattar'),
(33, 'Staff Member Updated [ID: 4, Abdul Sattar]', '2019-02-06 08:34:09', 'Abdul Sattar'),
(34, 'Staff Member Updated [ID: 4, Abdul Sattar]', '2019-02-06 08:34:31', 'Abdul Sattar'),
(35, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 08:57:24', 'Abdul Sattar'),
(36, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 08:58:24', 'Abdul Sattar'),
(37, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 08:58:31', 'Abdul Sattar'),
(38, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 09:02:26', 'Abdul Sattar'),
(39, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 09:02:30', 'Abdul Sattar'),
(40, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 09:51:15', 'Abdul Sattar'),
(41, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 09:51:19', 'Abdul Sattar'),
(42, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 09:51:27', 'Abdul Sattar'),
(43, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 09:54:33', 'Abdul Sattar'),
(44, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 09:57:16', 'Abdul Sattar'),
(45, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 09:58:04', 'Abdul Sattar'),
(46, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 09:58:16', 'Abdul Sattar'),
(47, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:01:38', 'Abdul Sattar'),
(48, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:02:04', 'Abdul Sattar'),
(49, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:02:37', 'Abdul Sattar'),
(50, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:02:50', 'Abdul Sattar'),
(51, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:03:43', 'Abdul Sattar'),
(52, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:04:19', 'Abdul Sattar'),
(53, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:04:53', 'Abdul Sattar'),
(54, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:05:11', 'Abdul Sattar'),
(55, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:05:22', 'Abdul Sattar'),
(56, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:05:32', 'Abdul Sattar'),
(57, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:05:41', 'Abdul Sattar'),
(58, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:06:56', 'Abdul Sattar'),
(59, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:08:13', 'Abdul Sattar'),
(60, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:10:43', 'Abdul Sattar'),
(61, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:10:55', 'Abdul Sattar'),
(62, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:11:20', 'Abdul Sattar'),
(63, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:11:57', 'Abdul Sattar'),
(64, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:12:51', 'Abdul Sattar'),
(65, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:14:13', 'Abdul Sattar'),
(66, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:14:17', 'Abdul Sattar'),
(67, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:21:05', 'Abdul Sattar'),
(68, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:21:10', 'Abdul Sattar'),
(69, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:21:45', 'Abdul Sattar'),
(70, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:22:11', 'Abdul Sattar'),
(71, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:31:06', 'Abdul Sattar'),
(72, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:34:33', 'Abdul Sattar'),
(73, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:34:41', 'Abdul Sattar'),
(74, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:36:18', 'Abdul Sattar'),
(75, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:41:23', 'Abdul Sattar'),
(76, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:54:45', 'Abdul Sattar'),
(77, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:55:25', 'Abdul Sattar'),
(78, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:55:48', 'Abdul Sattar'),
(79, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 10:57:24', 'Abdul Sattar'),
(80, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 11:01:14', 'Abdul Sattar'),
(81, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 11:01:16', 'Abdul Sattar'),
(82, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 11:01:18', 'Abdul Sattar'),
(83, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 11:02:11', 'Abdul Sattar'),
(84, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 11:02:35', 'Abdul Sattar'),
(85, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 11:16:44', 'Abdul Sattar'),
(86, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 11:16:52', 'Abdul Sattar'),
(87, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 11:18:47', 'Abdul Sattar'),
(88, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 11:18:53', 'Abdul Sattar'),
(89, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 11:19:13', 'Abdul Sattar'),
(90, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 11:19:28', 'Abdul Sattar'),
(91, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 11:19:30', 'Abdul Sattar'),
(92, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 11:22:09', 'Abdul Sattar'),
(93, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 11:25:06', 'Abdul Sattar'),
(94, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 11:25:07', 'Abdul Sattar'),
(95, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 12:16:08', 'Abdul Sattar'),
(96, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 12:16:11', 'Abdul Sattar'),
(97, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 12:55:21', 'Abdul Sattar'),
(98, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 12:56:31', 'Abdul Sattar'),
(99, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 12:57:22', 'Abdul Sattar'),
(100, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 14:08:24', 'Abdul Sattar'),
(101, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 14:19:59', 'Abdul Sattar'),
(102, 'Staff Member Updated [ID: 8, Super Admin]', '2019-02-06 14:21:31', 'Abdul Sattar'),
(103, 'New Staff Member Added [ID: 9, fasdf fsdafsa]', '2019-02-06 14:23:10', 'Abdul Sattar'),
(104, 'Staff Member Updated [ID: 9, fasdf fsdafsa]', '2019-02-06 14:23:19', 'Abdul Sattar'),
(105, 'Staff Member Updated [ID: 9, fasdf fsdafsa]', '2019-02-06 14:23:24', 'Abdul Sattar'),
(106, 'Staff Member Updated [ID: 9, fasdf fsdafsa]', '2019-02-06 14:23:26', 'Abdul Sattar');

-- --------------------------------------------------------

--
-- Table structure for table `tblcurrencies`
--

CREATE TABLE `tblcurrencies` (
  `id` int(11) NOT NULL,
  `symbol` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `isdefault` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbldepartments`
--

CREATE TABLE `tbldepartments` (
  `departmentid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `imap_username` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `email_from_header` tinyint(1) NOT NULL DEFAULT '0',
  `host` varchar(150) DEFAULT NULL,
  `password` mediumtext,
  `encryption` varchar(3) DEFAULT NULL,
  `delete_after_import` int(11) NOT NULL DEFAULT '0',
  `calendar_id` mediumtext,
  `hidefromclient` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbldepartments`
--

INSERT INTO `tbldepartments` (`departmentid`, `name`, `imap_username`, `email`, `email_from_header`, `host`, `password`, `encryption`, `delete_after_import`, `calendar_id`, `hidefromclient`) VALUES
(4, 'Finance', NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblnotifications`
--

CREATE TABLE `tblnotifications` (
  `id` int(11) NOT NULL,
  `isread` int(11) NOT NULL DEFAULT '0',
  `isread_inline` tinyint(1) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL,
  `description` text NOT NULL,
  `fromuserid` int(11) NOT NULL,
  `fromclientid` int(11) NOT NULL DEFAULT '0',
  `from_fullname` varchar(100) NOT NULL,
  `touserid` int(11) NOT NULL,
  `fromcompany` int(11) DEFAULT NULL,
  `link` mediumtext,
  `additional_data` varchar(600) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblpermissions`
--

CREATE TABLE `tblpermissions` (
  `permissionid` int(11) NOT NULL,
  `name` mediumtext NOT NULL,
  `shortname` mediumtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblpermissions`
--

INSERT INTO `tblpermissions` (`permissionid`, `name`, `shortname`) VALUES
(3, 'Settings', 'settings'),
(2, 'Staff', 'staff'),
(1, 'Roles', 'roles');

-- --------------------------------------------------------

--
-- Table structure for table `tblpermissions_copy`
--

CREATE TABLE `tblpermissions_copy` (
  `permissionid` int(11) NOT NULL,
  `name` mediumtext NOT NULL,
  `shortname` mediumtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblpermissions_copy`
--

INSERT INTO `tblpermissions_copy` (`permissionid`, `name`, `shortname`) VALUES
(1, 'Contracts', 'contracts'),
(2, 'Tasks', 'tasks'),
(3, 'Reports', 'reports'),
(4, 'Settings', 'settings'),
(5, 'Projects', 'projects'),
(6, 'Surveys', 'surveys'),
(7, 'Staff', 'staff'),
(8, 'Customers', 'customers'),
(9, 'Email Templates', 'email_templates'),
(10, 'Roles', 'roles'),
(11, 'Estimates', 'estimates'),
(12, 'Knowledge base', 'knowledge_base'),
(13, 'Proposals', 'proposals'),
(14, 'Goals', 'goals'),
(15, 'Expenses', 'expenses'),
(16, 'Bulk PDF Exporter', 'bulk_pdf_exporter'),
(17, 'Payments', 'payments'),
(18, 'Invoices', 'invoices'),
(19, 'Items', 'items'),
(20, 'Tasks Checklist Templates', 'checklist_templates'),
(21, 'Credit notes', 'credit_notes'),
(22, 'Leads', 'leads'),
(23, 'Subscriptions', 'subscriptions');

-- --------------------------------------------------------

--
-- Table structure for table `tblrolepermissions`
--

CREATE TABLE `tblrolepermissions` (
  `rolepermissionid` int(11) NOT NULL,
  `roleid` int(11) NOT NULL,
  `can_view` tinyint(1) NOT NULL DEFAULT '0',
  `can_view_own` tinyint(1) NOT NULL DEFAULT '0',
  `can_edit` tinyint(1) DEFAULT '0',
  `can_create` tinyint(1) NOT NULL DEFAULT '0',
  `can_delete` tinyint(1) NOT NULL DEFAULT '0',
  `permissionid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblrolepermissions`
--

INSERT INTO `tblrolepermissions` (`rolepermissionid`, `roleid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `permissionid`) VALUES
(1, 2, 1, 0, 1, 1, 1, 1),
(2, 2, 1, 0, 1, 0, 0, 3),
(3, 2, 0, 0, 0, 0, 0, 2),
(4, 1, 1, 0, 0, 1, 0, 1),
(5, 1, 0, 0, 0, 0, 0, 3),
(6, 1, 0, 0, 0, 0, 0, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tblroles`
--

CREATE TABLE `tblroles` (
  `roleid` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblroles`
--

INSERT INTO `tblroles` (`roleid`, `name`) VALUES
(1, 'Super Admin'),
(2, 'Employee');

-- --------------------------------------------------------

--
-- Table structure for table `tblstaff`
--

CREATE TABLE `tblstaff` (
  `staffid` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `facebook` mediumtext,
  `linkedin` mediumtext,
  `phonenumber` varchar(30) DEFAULT NULL,
  `skype` varchar(50) DEFAULT NULL,
  `password` varchar(250) NOT NULL,
  `datecreated` datetime NOT NULL,
  `profile_image` varchar(300) DEFAULT NULL,
  `last_ip` varchar(40) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_activity` datetime DEFAULT NULL,
  `last_password_change` datetime DEFAULT NULL,
  `new_pass_key` varchar(32) DEFAULT NULL,
  `new_pass_key_requested` datetime DEFAULT NULL,
  `admin` int(11) NOT NULL DEFAULT '0',
  `role` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  `default_language` varchar(40) DEFAULT NULL,
  `direction` varchar(3) DEFAULT NULL,
  `media_path_slug` varchar(300) DEFAULT NULL,
  `is_not_staff` int(11) NOT NULL DEFAULT '0',
  `hourly_rate` decimal(15,2) NOT NULL DEFAULT '0.00',
  `two_factor_auth_enabled` tinyint(1) DEFAULT '0',
  `two_factor_auth_code` varchar(100) DEFAULT NULL,
  `two_factor_auth_code_requested` datetime DEFAULT NULL,
  `email_signature` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblstaff`
--

INSERT INTO `tblstaff` (`staffid`, `email`, `firstname`, `lastname`, `facebook`, `linkedin`, `phonenumber`, `skype`, `password`, `datecreated`, `profile_image`, `last_ip`, `last_login`, `last_activity`, `last_password_change`, `new_pass_key`, `new_pass_key_requested`, `admin`, `role`, `active`, `default_language`, `direction`, `media_path_slug`, `is_not_staff`, `hourly_rate`, `two_factor_auth_enabled`, `two_factor_auth_code`, `two_factor_auth_code_requested`, `email_signature`) VALUES
(1, 'admin@admin.com', 'Abdul', 'Sattar', NULL, NULL, NULL, NULL, '$2a$08$PnGkA8FS6TfCOGRKSN03T.E3jgWgYV4Qtv4kkyaGH6jRyJKHlrNcu', '2018-06-12 08:04:24', NULL, '::1', '2019-02-08 10:51:52', '2019-02-08 13:55:27', NULL, NULL, NULL, 1, NULL, 1, NULL, NULL, NULL, 0, '0.00', 0, NULL, NULL, NULL),
(2, 'employee@employee.com', 'Employee1', 'Employee1', '', '', '', '', '$2a$08$9icP2jWPFVNkOxnqHu/Mr.fIVzZMUhRk3MjfTsNktTY6ft2fulXFW', '2018-06-12 13:00:16', 'naveen.jpg', '::1', '2019-02-04 08:53:45', '2019-02-04 10:33:03', '2019-02-06 06:44:47', NULL, NULL, 0, 1, 1, '', '', 'employee1-employee1', 0, '0.00', 0, NULL, NULL, ''),
(4, 'abdulsattar@meetingsint.com', 'Abdul', 'Sattar', NULL, NULL, '9849944535', NULL, '$2a$08$mGLGq8.OpSE.QfApTKzUqu9UTZU.Vhfv/a9EvihRitEThAHJRHWmC', '2019-02-05 08:12:39', NULL, '::1', '2019-02-05 08:22:23', '2019-02-05 08:27:06', '2019-02-06 08:34:31', NULL, NULL, 0, 1, 1, NULL, NULL, NULL, 0, '0.00', 0, NULL, NULL, ''),
(5, 'sivaprasadreddy@omicsgroup.co.in', 'Siva', 'Prasad', NULL, NULL, '9849944585', NULL, '$2a$08$2pDV9Iwq6h.Fsq7RQk01BuZ7j0hMm6F1PjsBjIJi4oihae3JOz.o.', '2019-02-05 08:27:59', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 2, 1, NULL, NULL, NULL, 0, '0.00', 0, NULL, NULL, ''),
(7, 'ram@gmail.com', 'ram', 'prads', NULL, NULL, '9848888595', NULL, '$2a$08$VV9WJxSMEnRSagcd2Ztzq.yQBTKxA7D7GhxvJicoHvYZ9TEE7UMYq', '2019-02-05 08:36:52', NULL, '::1', '2019-02-05 08:39:30', '2019-02-05 08:39:51', NULL, NULL, NULL, 0, 2, 1, NULL, NULL, 'ram prads', 0, '0.00', 0, NULL, NULL, ''),
(8, 'admin@admin.com', 'Super', 'Admin', NULL, NULL, '', NULL, '$2a$08$/e9J0CtoVbPzanQsITzXauk7Plzx5gDfIt/D/XC.hQ2UUQMU62u0y', '2019-02-05 08:47:43', 'naveen-3.jpg', '::1', '2019-02-05 08:50:11', '2019-02-05 09:59:10', '2019-02-06 14:21:31', NULL, NULL, 0, 1, 1, NULL, NULL, 'xxxx ddddd', 0, '0.00', 0, NULL, NULL, ''),
(9, 'fsafsdsfd@sdfsdaf.com', 'fasdf', 'fsdafsa', NULL, NULL, '123456', NULL, '$2a$08$UNi/9YRVI5TUyH8vc8pxDukUJxJTDTChEbMAuEIwtPXh5folmyX9W', '2019-02-06 14:23:10', NULL, NULL, NULL, NULL, '2019-02-06 14:23:26', NULL, NULL, 0, 1, 1, NULL, NULL, 'fasdf fsdafsa', 0, '0.00', 0, NULL, NULL, '');

-- --------------------------------------------------------

--
-- Table structure for table `tblstaffdepartments`
--

CREATE TABLE `tblstaffdepartments` (
  `staffdepartmentid` int(11) NOT NULL,
  `staffid` int(11) NOT NULL,
  `departmentid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblstaffpermissions`
--

CREATE TABLE `tblstaffpermissions` (
  `staffpermid` int(11) NOT NULL,
  `permissionid` int(11) NOT NULL,
  `can_view` tinyint(1) NOT NULL DEFAULT '0',
  `can_view_own` tinyint(1) NOT NULL DEFAULT '0',
  `can_edit` tinyint(1) NOT NULL DEFAULT '0',
  `can_create` tinyint(1) NOT NULL DEFAULT '0',
  `can_delete` tinyint(1) NOT NULL DEFAULT '0',
  `staffid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tblstaffpermissions`
--

INSERT INTO `tblstaffpermissions` (`staffpermid`, `permissionid`, `can_view`, `can_view_own`, `can_edit`, `can_create`, `can_delete`, `staffid`) VALUES
(1, 1, 1, 0, 1, 1, 1, 2),
(2, 1, 0, 0, 0, 0, 0, 6),
(3, 3, 0, 0, 0, 0, 0, 6),
(4, 2, 0, 0, 0, 0, 0, 6),
(5, 1, 1, 0, 1, 1, 1, 7),
(6, 3, 1, 0, 1, 0, 0, 7),
(7, 2, 0, 0, 0, 0, 0, 7),
(8, 1, 1, 0, 1, 1, 1, 8),
(9, 3, 1, 0, 1, 0, 0, 8),
(10, 2, 1, 0, 1, 1, 1, 8),
(11, 1, 1, 0, 1, 1, 1, 5),
(12, 3, 1, 0, 1, 0, 0, 5),
(13, 2, 0, 0, 0, 0, 0, 5),
(14, 3, 1, 0, 1, 0, 0, 2),
(15, 2, 0, 0, 0, 0, 0, 2),
(16, 1, 1, 0, 1, 1, 1, 4),
(17, 3, 1, 0, 1, 0, 0, 4),
(18, 2, 0, 0, 0, 0, 0, 4),
(19, 1, 0, 0, 0, 0, 0, 9),
(20, 3, 0, 0, 0, 0, 0, 9),
(21, 2, 0, 0, 0, 0, 0, 9);

-- --------------------------------------------------------

--
-- Table structure for table `tbluserautologin`
--

CREATE TABLE `tbluserautologin` (
  `key_id` char(32) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_agent` varchar(150) NOT NULL,
  `last_ip` varchar(40) NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `staff` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblactivitylog`
--
ALTER TABLE `tblactivitylog`
  ADD PRIMARY KEY (`id`),
  ADD KEY `staffid` (`staffid`);

--
-- Indexes for table `tblcurrencies`
--
ALTER TABLE `tblcurrencies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbldepartments`
--
ALTER TABLE `tbldepartments`
  ADD PRIMARY KEY (`departmentid`),
  ADD KEY `name` (`name`);

--
-- Indexes for table `tblnotifications`
--
ALTER TABLE `tblnotifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblpermissions`
--
ALTER TABLE `tblpermissions`
  ADD PRIMARY KEY (`permissionid`);

--
-- Indexes for table `tblpermissions_copy`
--
ALTER TABLE `tblpermissions_copy`
  ADD PRIMARY KEY (`permissionid`);

--
-- Indexes for table `tblrolepermissions`
--
ALTER TABLE `tblrolepermissions`
  ADD PRIMARY KEY (`rolepermissionid`);

--
-- Indexes for table `tblroles`
--
ALTER TABLE `tblroles`
  ADD PRIMARY KEY (`roleid`);

--
-- Indexes for table `tblstaff`
--
ALTER TABLE `tblstaff`
  ADD PRIMARY KEY (`staffid`),
  ADD KEY `firstname` (`firstname`),
  ADD KEY `lastname` (`lastname`);

--
-- Indexes for table `tblstaffdepartments`
--
ALTER TABLE `tblstaffdepartments`
  ADD PRIMARY KEY (`staffdepartmentid`);

--
-- Indexes for table `tblstaffpermissions`
--
ALTER TABLE `tblstaffpermissions`
  ADD PRIMARY KEY (`staffpermid`),
  ADD KEY `permissionid` (`permissionid`),
  ADD KEY `staffid` (`staffid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblactivitylog`
--
ALTER TABLE `tblactivitylog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;

--
-- AUTO_INCREMENT for table `tblcurrencies`
--
ALTER TABLE `tblcurrencies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbldepartments`
--
ALTER TABLE `tbldepartments`
  MODIFY `departmentid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblnotifications`
--
ALTER TABLE `tblnotifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblpermissions`
--
ALTER TABLE `tblpermissions`
  MODIFY `permissionid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `tblpermissions_copy`
--
ALTER TABLE `tblpermissions_copy`
  MODIFY `permissionid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `tblrolepermissions`
--
ALTER TABLE `tblrolepermissions`
  MODIFY `rolepermissionid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tblroles`
--
ALTER TABLE `tblroles`
  MODIFY `roleid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblstaff`
--
ALTER TABLE `tblstaff`
  MODIFY `staffid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tblstaffdepartments`
--
ALTER TABLE `tblstaffdepartments`
  MODIFY `staffdepartmentid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblstaffpermissions`
--
ALTER TABLE `tblstaffpermissions`
  MODIFY `staffpermid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
