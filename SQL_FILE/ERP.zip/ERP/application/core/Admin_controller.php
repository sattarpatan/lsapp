<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Admin_controller extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->model('authentication/authentication_model');
        $this->authentication_model->autologin();

        if (!is_staff_logged_in()) {
            if (strpos(current_full_url(), 'authentication/admin') === false) {
                redirect_after_login_to_current_url();
            }
            redirect(site_url('authentication/admin'));
        }

        // In case staff have setup logged in as client - This is important don't change it
        foreach (['client_user_id', 'contact_user_id', 'client_logged_in', 'logged_in_as_client'] as $sk) {
            if ($this->session->has_userdata($sk)) {
                $this->session->unset_userdata($sk);
            }
        }

        // Update staff last activity
        $this->db->where('staffid', get_staff_user_id());
        $this->db->update('tblstaff', ['last_activity' => date('Y-m-d H:i:s')]);

        $this->load->model('staff/staff_model');

       
        $currentUser = $this->staff_model->get(get_staff_user_id());

        // Deleted or inactive but have session
        if (!$currentUser || $currentUser->active == 0) {
            $this->authentication_model->logout();
            redirect(site_url('authentication/admin'));
        }

        $GLOBALS['current_user'] = $currentUser;
        //$language                = load_admin_language();

       $auto_loaded_vars = [
            'current_user'         => $currentUser,
            //'app_language'         => $language,
            //'locale'               => get_locale_key($language),
            //'current_version'      => $this->current_db_version,
            //'task_statuses'        => $this->tasks_model->get_statuses(),
            'unread_notifications' => $currentUser->total_unread_notifications, // Deprecated
        ];

        $auto_loaded_vars = do_action('before_set_auto_loaded_vars_admin_area', $auto_loaded_vars);
        /*  $this->load->vars($auto_loaded_vars); */

        /* if (!$is_ajax_request) {
            $this->init_quick_actions_links();
        } */
    }

    
}
