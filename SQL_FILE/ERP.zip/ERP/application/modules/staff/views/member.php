<!-- Content Header (Page header) -->
<section class="content-header">
   <h1>
      Employee Form
   </h1>
   <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="#">Examples</a></li>
      <li class="active">User profile</li>
   </ol>
</section>
<!-- Main content -->
<section class="content">
   <div class="row">
      <!-- /.col -->
      <div class="col-md-12">
         <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
               <li class="active"><a href="#tab_staff_profile" data-toggle="tab">Add new role</a></li>
               <li class=""><a href="#tab_staff_permissions" data-toggle="tab">Permissions</a></li>
            </ul>
			
            <?php 
			echo form_open_multipart($this->uri->uri_string(),array('class'=>'form-horizontal','autocomplete'=>'off')); ?>
            <div class="tab-content">
               <div class="tab-pane active" id="tab_staff_profile">
                  <div class="post">
					
					<?php if((isset($member) && $member->profile_image == NULL) || !isset($member)){ ?>
                     <div class="form-group">
                        <label for="profile_image" class="col-sm-2  control-label"><?php echo 'Profile Image'; ?></label>
						<div class="col-sm-8 col-offset-right-2">
							<input type="file" name="profile_image" class="form-control" id="profile_image">
						</div>
                     </div>
                     <?php } ?>
				  
                     <div class="form-group">
                        <label for="inputName" class="col-sm-2 control-label">First Name</label>
                        <div class="col-sm-8 col-offset-right-2">
                           <?php 
								$value = (isset($member) ? $member->firstname : '');$data = array(
								  'name'        => 'firstname',
								  'id'          => 'firstname',
								  'value'       => $value,
								  'class'		=> 'form-control',
								  'autofocus'=>true,
								  'placeholder' => 'Last Name',		
								);
								echo form_input($data); 
							?>
						   
                        </div>
                     </div>
                     <div class="form-group">
                        <label for="inputName" class="col-sm-2 control-label">Last Name</label>
                        <div class="col-sm-8 col-offset-right-2">
                           <?php 
								$value = (isset($member) ? $member->lastname : '');$data = array(
								  'name'        => 'lastname',
								  'id'          => 'lastname',
								  'value'       => $value,
								  'class'		=> 'form-control',
								  'autofocus'=>true,
								  'placeholder' => 'First Name',								  
								);
								echo form_input($data); 
							?>
                        </div>
                     </div>
                     <div class="form-group">
                        <label for="inputEmail" class="col-sm-2 control-label">Email</label>
                        <div class="col-sm-8 col-offset-right-2">
                           <?php 
								$value = (isset($member) ? $member->email : '');$data = array(
								  'name'        => 'email',
								  'id'          => 'email',
								  'value'       => $value,
								  'class'		=> 'form-control',
								  'autofocus'=>true,
								  'placeholder' => 'Email',
								);
								echo form_input($data); 
							?>
                        </div>
                     </div>
                     <div class="form-group">
                        <label for="inputName" class="col-sm-2 control-label">Phone</label>
                        <div class="col-sm-8 col-offset-right-2">
                           <?php 
								$value = (isset($member) ? $member->phonenumber : '');$data = array(
								  'name'        => 'phonenumber',
								  'id'          => 'phonenumber',
								  'value'       => $value,
								  'class'		=> 'form-control',
								  'autofocus'=>true,
								  'placeholder' => 'Phone Number',					  
								);
								echo form_input($data); 
							?>
                        </div>
                     </div>
                     <div class="form-group">
                        <label for="inputExperience" class="col-sm-2 control-label">Password</label>
                        <div class="col-sm-8 col-offset-right-2">
                           <?php 
								$value = (isset($member) ? $member->password : '');$data = array(
								  'name'        => 'password',
								  'id'          => 'password',
								  'value'       => $value,
								  'class'		=> 'form-control',
								  'autofocus'	=>true								  
								);
								echo form_password($data); 
							?>						   
                        </div>
                     </div>                     
                     <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                           <button type="submit" class="btn btn-info btn-flat">Submit</button>
                        </div>
                     </div>
					 <div class="form-group"></div>
                     
                  </div>
               </div>
               <div class="tab-pane" id="tab_staff_permissions">
                  <!-- Post -->
                  <div class="post">
                     <div class="form-group"></div>
                     <div class="form-group">
                        <label for="inputName" class="col-sm-2 control-label">Role Name</label>
                        <div class="col-sm-8 col-offset-right-2">
							<?php
                              echo '<select name="role" class="form-control">';			
                              foreach($roles as $rolez){
								echo '<option value="'.$rolez['roleid'].'">'.$rolez['name'].'</option>';
                              }
                              echo '</select>';
                            ?>
							<?php
							//do_action('staff_render_permissions');
							/* $selected = '';
							foreach($roles as $role){
								if(isset($member)){
								  if($member->role == $role['roleid']){
								   $selected = $role['roleid'];
								 }
								} else {
									$default_staff_role = get_option('default_staff_role');
									if($default_staff_role == $role['roleid'] ){
									 $selected = $role['roleid'];
									}
								}
							} */
							?>  
							  
                        </div>
                     </div>
                     <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-8 col-offset-right-2">
                           <div class="table-responsive">
                              <table class="table table-bordered roles no-margin">
                                 <thead>
                                    <tr>
                                       <th class="bold"><?php echo 'Permission'; ?></th>
                                       <th class="text-center bold"><?php echo 'View'; ?></th>
                                       <th class="text-center bold"><?php echo 'View (Own)'; ?></th>
                                       <th class="text-center bold"><?php echo 'Create'; ?></th>
                                       <th class="text-center bold"><?php echo 'Edit'; ?></th>
                                       <th class="text-center text-danger bold"><?php echo 'Delete'; ?></th>
                                    </tr>
                                 </thead>
                                 <tbody>
                                    <?php
                                       $conditions = get_permission_conditions();
                                       foreach($permissions as $permission){
                                       $permission_condition = $conditions[$permission['shortname']];
                                       ?>
                                    <tr>
                                       <td>
                                          <?php echo $permission['name']; ?>
                                       </td>
                                       <td class="text-center">
									   
	<?php if($permission_condition['view'] == true){
	   $statement = '';
	   if(isset($is_admin) && $is_admin || isset($member) && has_permission($permission['shortname'],$member->staffid,'view_own')){
		$statement = 'disabled';
	   } else if(isset($member) && has_permission($permission['shortname'],$member->staffid,'view')){
		$statement = 'checked';
	   }
	   ?>
	<?php
	   if(isset($permission_condition['help'])){
		 echo '<i class="fa fa-question-circle text-danger" data-toggle="tooltip" data-title="'.$permission_condition['help'].'"></i>';
	   }
	   ?>
	<div class="checkbox">
	   <input type="checkbox" data-can-view <?php echo $statement; ?> name="view[]" value="<?php echo $permission['permissionid']; ?>">
	   <label></label>
	</div>
	<?php } ?>
	
                                       </td>
                                       <td class="text-center">
<?php if($permission_condition['view_own'] == true){
   $statement = '';
   if(isset($is_admin) && $is_admin || isset($member) && has_permission($permission['shortname'],$member->staffid,'view')){
	$statement = 'disabled';
   } else if(isset($member) && has_permission($permission['shortname'],$member->staffid,'view_own')){
	$statement = 'checked';
   }
   ?>
<div class="checkbox">
   <input type="checkbox" <?php echo $statement; ?> data-shortname="<?php echo $permission['shortname']; ?>" data-can-view-own name="view_own[]" value="<?php echo $permission['permissionid']; ?>">
   <label></label>
</div>
<?php } else if($permission['shortname'] == 'customers'){
   echo '<i class="fa fa-question-circle mtop5" data-toggle="tooltip" data-title="permission_customers_based_on_admins"></i>';
   } else if($permission['shortname'] == 'projects'){
   echo '<i class="fa fa-question-circle mtop15" data-toggle="tooltip" data-title="permission_projects_based_on_assignee"></i>';
   } else if($permission['shortname'] == 'tasks'){
   echo '<i class="fa fa-question-circle mtop15" data-toggle="tooltip" data-title="permission_tasks_based_on_assignee"></i>';
   } else if($permission['shortname'] == 'payments'){
   echo '<i class="fa fa-question-circle mtop5" data-toggle="tooltip" data-title="permission_payments_based_on_invoices"></i>';
   } 
?>
									   
                                         
                                       </td>
                                       <td class="text-center">
									   
<?php if($permission_condition['create'] == true){
   $statement = '';
   if(isset($is_admin) && $is_admin){
	$statement = 'disabled';
   } else if(isset($member) && has_permission($permission['shortname'],$member->staffid,'create')){
	$statement = 'checked';
   }
   ?>
<div class="checkbox">
   <input type="checkbox" data-shortname="<?php echo $permission['shortname']; ?>" data-can-create <?php echo $statement; ?> name="create[]" value="<?php echo $permission['permissionid']; ?>">
   <label></label>
</div>
<?php } ?>
 <?php
   if(isset($permission_condition['help_create'])){
	 echo '<i class="fa fa-question-circle" data-toggle="tooltip" data-title="'.$permission_condition['help_create'].'"></i>';
   }
?>									   
									   
                                         
                                       </td>
                                       <td class="text-center">
<?php if($permission_condition['edit'] == true){
   $statement = '';
   if(isset($is_admin) && $is_admin){
	$statement = 'disabled';
   } else if(isset($member) && has_permission($permission['shortname'],$member->staffid,'edit')){
	$statement = 'checked';
   }
   ?>
<div class="checkbox">
   <input type="checkbox" data-shortname="<?php echo $permission['shortname']; ?>" data-can-edit <?php echo $statement; ?> name="edit[]" value="<?php echo $permission['permissionid']; ?>">
   <label></label>
</div>
<?php } ?>
 <?php
   if(isset($permission_condition['help_edit'])){
	 echo '<i class="fa fa-question-circle" data-toggle="tooltip" data-title="'.$permission_condition['help_edit'].'"></i>';
   }
?>
                                         
                                       </td>
                                       <td class="text-center">

<?php if($permission_condition['delete'] == true){
   $statement = '';
   if(isset($is_admin) && $is_admin){
	 $statement = 'disabled';
   } else if(isset($member) && has_permission($permission['shortname'],$member->staffid,'delete')){
	 $statement = 'checked';
   }
   ?>
<div class="checkbox checkbox-danger">
   <input type="checkbox" data-shortname="<?php echo $permission['shortname']; ?>" data-can-delete <?php echo $statement; ?> name="delete[]" value="<?php echo $permission['permissionid']; ?>">
   <label></label>
</div>
<?php } ?>										
									   
                                          
                                       </td>
                                    </tr>
                                    <?php } ?>
                                 </tbody>
                              </table>
                           </div>
                        </div>
                     </div>
					<div class="form-group">
                     <div class="col-sm-offset-2 col-sm-10">
                        <button type="submit" class="btn btn-info btn-flat">Submit</button>
                     </div>
                  </div>
				  <div class="form-group"></div> 
                  </div>
                  
               </div>
            
            </form>
            <!-- /.tab-pane -->              
         </div>
         <!-- /.tab-content -->
      </div>
      <!-- /.nav-tabs-custom -->
     </div>
   <!-- /.col -->
   </div>
   <!-- /.row -->
</section>
<!-- /.content -->
<script>
   $(function() {

       $('select[name="role"]').on('change', function() {
           var roleid = $(this).val();
		   
		  
		   
           init_roles_permissions(roleid, true);
       });
   });
   
   
 // Called when editing member profile
function init_roles_permissions(roleid, user_changed) {
    roleid = typeof(roleid) == 'undefined' ? $('select[name="role"]').val() : roleid;
	
    var isedit = $('.member > input[name="isedit"]');

    // Check if user is edit view and user has changed the dropdown permission if not only return
    if (isedit.length > 0 && typeof(roleid) !== 'undefined' && typeof(user_changed) == 'undefined') {
        return;
    }

    // Administrators does not have permissions
    if ($('input[name="administrator"]').prop('checked') === true) {
        return;
    }

    // Last if the roleid is blank return
    if (roleid === '') {
        return;
    }

    // Get all permissions
    var permissions = $('table.roles').find('tr');
	
	requestGetJSON('<?php echo base_url();?>misc/get_role_permissions_ajax/' + roleid).done(function(response) {
        var can_view_st, can_view_own_st;

        $.each(permissions, function() {
            var permissionid = $(this).data('id');
            var row = $(this);

            // No permissions for this role
            if (response.length === 0) {
                row.find('input[type="checkbox"]').prop('checked', false);
            }

            $.each(response, function(i, obj) {
                if (permissionid == obj.permissionid) {
                    can_view_st = (obj.can_view == 1 ? true : false);
                    can_view_own_st = (obj.can_view_own == 1 ? true : false);
                    row.find('[data-can-view]').prop('checked', can_view_st);
                    if (can_view_st === true) {
                        row.find('[data-can-view]').change();
                    }
                    row.find('[data-can-view-own]').prop('checked', can_view_own_st);
                    if (can_view_own_st === true) {
                        row.find('[data-can-view-own]').change();
                    }
                    row.find('[data-can-edit]').prop('checked', (obj.can_edit == 1 ? true : false));
                    row.find('[data-can-create]').prop('checked', (obj.can_create == 1 ? true : false));
                    row.find('[data-can-delete]').prop('checked', (obj.can_delete == 1 ? true : false));
                }
            });
        });
    });
}  

// General helper function for $.get ajax requests with dataType JSON
function requestGetJSON(uri, params) {
    params = typeof(params) == 'undefined' ? {} : params;
    params.dataType = 'json';
    return requestGet(uri, params);
}

// General helper function for $.get ajax requests
function requestGet(uri, params) {
    params = typeof(params) == 'undefined' ? {} : params;
	var admin_url ='';
    var options = {
        type: 'GET',
        url: uri.indexOf(admin_url) > -1 ? uri : admin_url + uri
    };
    return $.ajax($.extend({}, options, params));
}
</script>   