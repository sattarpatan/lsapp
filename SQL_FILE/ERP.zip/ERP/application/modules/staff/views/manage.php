      <!-- Page header -->
<section class="content-header">
	<h1>Staff Management</h1>
	<ol class="breadcrumb">
		<li><a href="http://ums.clustercoding.com/demo/admin/dashboard"><i class="fa fa-home"></i> Dashboard</a></li>
		<li class="active">Page</li>
	</ol>
</section>
<!-- /.page header -->
<!-- Main content -->
<section class="content">
	<div class="box">
		<div class="box-header with-border">
			<h3 class="box-title">Add Staff Members</h3>

			<div class="box-tools">
				<a href="<?php echo site_url('staff/member'); ?>" type="button" class="btn btn-info btn-sm btn-flat add-button"><i class="fa fa-plus"></i> New Staff Member</a>
			</div>
		</div>
		<!-- /.box-header -->
		<div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Full Name</th>
                  <th>Email</th>
                  <th>Last Login</th>
				  <th>Action</th>
                </tr>
                </thead>
                <tbody>                
				<?php
				/* echo "<pre>";				
				print_r($staff_members);
				echo "</pre>"; */				
				
				foreach($staff_members as $staff){?>
				<tr>	
                  <td><?php echo $staff['full_name'];?></td>
                  <td><?php echo $staff['email'];?></td>
                  <td><?php echo $staff['last_login'];?></td>
                  <td>
				  <a href="<?php echo site_url('staff/view/'.$staff['staffid']);?>"><button class="btn btn-info btn-xs view-button"><i class="fa fa-eye"></i></button></a>
				  <a href="<?php echo site_url('staff/member/'.$staff['staffid']);?>"><button class="btn btn-primary btn-xs edit-button"><i class="fa fa-edit"></i></button></a>
				  <a href="<?php echo site_url('staff/delete/'.$staff['staffid']);?>" id="delete-button"><button class="btn btn-danger btn-xs delete-button"><i class="fa fa-trash"></i></button></a></td>
                </tr>
                <?php } ?>                
                </tbody>
                <tfoot>
                <tr>
                  <th>Full Name</th>
                  <th>Email</th>
                  <th>Last Login</th>
				  <th>Action</th>
                </tr>
                </tfoot>
              </table>
            </div>
		<!-- /.box-body -->
		<div class="box-footer clearfix">
		</div>
	</div>
</section>
<!-- /.main content -->
