      <!-- Page header -->
<section class="content-header">
	<h1>
		SETTING
	</h1>
	<ol class="breadcrumb">
		<li><a href="http://ums.clustercoding.com/demo/admin/dashboard"><i class="fa fa-home"></i> Dashboard</a></li>
		<li class="active">Setting</li>
	</ol>
</section>
<!-- /.page header -->

<!-- Main content -->
<section class="content">

	<div class="row">
		<div class="col-md-12">
			<div class="nav-tabs-custom">
				<ul class="nav nav-tabs">
					<li class="active"><a href="#logo" data-toggle="tab">Logo</a></li>
					<li><a href="#favicon" data-toggle="tab">Favicon</a></li>
					<li><a href="#general" data-toggle="tab">General</a></li>
					<li><a href="#contact" data-toggle="tab">Contact</a></li>
					<li><a href="#address" data-toggle="tab">Address</a></li>
					<li><a href="#social_link" data-toggle="tab">Social Link</a></li>
					<li><a href="#home_page" data-toggle="tab">Home Page</a></li>
					<li><a href="#gallery_page_meta" data-toggle="tab">Gallery Page Meta</a></li>
				</ul>
				<div class="tab-content">
					<div class="active tab-pane" id="logo">
						<form data-parsley-validate="" class="form-horizontal" action="http://ums.clustercoding.com/demo/admin/setting/logo/1" method="post" enctype="multipart/form-data" novalidate="">
							<input type="hidden" name="_token" value="TyITdCmdMvfIeYp8TG2gjpyb9s4kmvyHXbnrHJ0A">
							<div class="form-group">
								<label class="col-sm-2 control-label"></label>
								<div class="col-sm-10">
									<img src="http://ums.clustercoding.com/demo/public/web/logo/logo.png" width="262" class="img-responsive">
								</div>
							</div>
							<div class="form-group">
								<label for="logo" class="col-sm-2 control-label">New Logo</label>
								<div class="col-sm-3">
									<input type="file" name="logo" class="form-control" id="logo" required="">
																	</div>
							</div>
							<div class="form-group">
								<div class="col-sm-offset-2 col-sm-10">
									<button type="submit" class="btn btn-info btn-flat">Update</button>
								</div>
							</div>
						</form>
					</div>
					<!-- /.tab-pane -->
					<div class="tab-pane" id="favicon">
						<form data-parsley-validate="" class="form-horizontal" action="http://ums.clustercoding.com/demo/admin/setting/favicon/1" method="post" enctype="multipart/form-data" novalidate="">
							<input type="hidden" name="_token" value="TyITdCmdMvfIeYp8TG2gjpyb9s4kmvyHXbnrHJ0A">
							<div class="form-group">
								<label class="col-sm-2 control-label"></label>
								<div class="col-sm-10">
									<img src="http://ums.clustercoding.com/demo/public/web/favicon/favicon.png" width="32" class="img-responsive">
								</div>
							</div>
							<div class="form-group">
								<label for="favicon" class="col-sm-2 control-label">New Logo</label>
								<div class="col-sm-3">
									<input type="file" name="favicon" class="form-control" id="favicon" required="">
																	</div>
							</div>
							<div class="form-group">
								<div class="col-sm-offset-2 col-sm-10">
									<button type="submit" class="btn btn-info btn-flat">Update</button>
								</div>
							</div>
						</form>
					</div>
					<!-- /.tab-pane -->

					<div class="tab-pane" id="general">
						<form data-parsley-validate="" class="form-horizontal" action="http://ums.clustercoding.com/demo/admin/setting/general/1" method="post" novalidate="">
							<input type="hidden" name="_token" value="TyITdCmdMvfIeYp8TG2gjpyb9s4kmvyHXbnrHJ0A">
							<div class="form-group">
								<label for="map_iframe" class="col-sm-2 control-label">Map iFrame</label>
								<div class="col-sm-10">
									<textarea name="map_iframe" class="form-control" id="map_iframe" rows="6" placeholder="ex. google map iframe" maxlength="500">&lt;iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2642905.2881059386!2d89.27605108245604!3d23.817470325158617!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30adaaed80e18ba7%3A0xf2d28e0c4e1fc6b!2sBangladesh!5e0!3m2!1sen!2sbd!4v1520764767552" width="600" height="450" frameborder="0" style="border:0" allowfullscreen&gt;&lt;/iframe&gt;</textarea>
																	</div>
							</div>
							<div class="form-group">
								<label for="about_us" class="col-sm-2 control-label">Footer About Us</label>
								<div class="col-sm-10">
									<textarea name="about_us" class="form-control" id="about_us" placeholder="ex. about us" rows="6" required="" maxlength="500">ClusterCoding is among the pioneers in the Bangladesh to offer quality web services to medium and large sized businesses to compete in today’s digital world. We possess the experience and expertise to help web entrepreneurs reach their customers across the digital space.</textarea>
																	</div>
							</div>
							<div class="form-group">
								<label for="copyright" class="col-sm-2 control-label">Copyright</label>
								<div class="col-sm-10">
									<input type="text" name="copyright" class="form-control" id="copyright" value="Copyright 2018 <a href=&quot;http://clustercoding.com&quot; target=&quot;_blank&quot;>Clustercoding</a>, All rights reserved." placeholder="ex. Copyright 2018 Clustercoding, All rights reserved." required="" maxlength="250">
																	</div>
							</div>
							<div class="form-group">
								<div class="col-sm-offset-2 col-sm-10">
									<button type="submit" class="btn btn-info btn-flat">Update</button>
								</div>
							</div>
						</form>
					</div>
					<!-- /.tab-pane -->
					<div class="tab-pane" id="contact">
						<form data-parsley-validate="" class="form-horizontal" action="http://ums.clustercoding.com/demo/admin/setting/contact/1" method="post" novalidate="">
							<input type="hidden" name="_token" value="TyITdCmdMvfIeYp8TG2gjpyb9s4kmvyHXbnrHJ0A">
							<div class="form-group">
								<label for="email" class="col-sm-2 control-label">Email</label>
								<div class="col-sm-10">
									<input type="text" name="email" class="form-control" id="email" value="clustercoding@gmail.com" placeholder="ex. clustercoding@gmail.com" required="" maxlength="100">
																	</div>
							</div>
							<div class="form-group">
								<label for="phone" class="col-sm-2 control-label">Phone</label>
								<div class="col-sm-10">
									<input type="text" name="phone" class="form-control" id="phone" value="+8801717888464" placeholder="ex. XXXXXXXXXXX" maxlength="25">
																	</div>
							</div>
							<div class="form-group">
								<label for="mobile" class="col-sm-2 control-label">Mobile</label>
								<div class="col-sm-10">
									<input type="text" name="mobile" class="form-control" id="mobile" value="+8801761913331" placeholder="ex. XXXXXXXXXXX" maxlength="25">
																	</div>
							</div>
							<div class="form-group">
								<label for="fax" class="col-sm-2 control-label">Fax</label>
								<div class="col-sm-10">
									<input type="text" name="fax" class="form-control" id="fax" value="808080" placeholder="ex. XXXXXX" maxlength="20">
																	</div>
							</div>
							<div class="form-group">
								<div class="col-sm-offset-2 col-sm-10">
									<button type="submit" class="btn btn-info btn-flat">Update</button>
								</div>
							</div>
						</form>
					</div>
					<!-- /.tab-pane -->
					<div class="tab-pane" id="address">
						<form data-parsley-validate="" class="form-horizontal" action="http://ums.clustercoding.com/demo/admin/setting/address/1" method="post" novalidate="">
							<input type="hidden" name="_token" value="TyITdCmdMvfIeYp8TG2gjpyb9s4kmvyHXbnrHJ0A">
							<div class="form-group">
								<label for="address_line_one" class="col-sm-2 control-label">Address Line 1</label>
								<div class="col-sm-10">
									<input type="text" name="address_line_one" class="form-control" id="email" value="House# 83, Road# 16, Sector# 11" placeholder="ex. address" maxlength="250">
																	</div>
							</div>
							<div class="form-group">
								<label for="address_line_two" class="col-sm-2 control-label">Address Line 2</label>
								<div class="col-sm-10">
									<input type="text" name="address_line_two" class="form-control" id="address_line_two" value="Banani" placeholder="ex. address" maxlength="250">
																	</div>
							</div>
							<div class="form-group">
								<label for="state" class="col-sm-2 control-label">state</label>
								<div class="col-sm-10">
									<input type="text" name="state" class="form-control" id="state" value="Uttara" placeholder="ex. state" maxlength="50">
																	</div>
							</div>
							<div class="form-group">
								<label for="city" class="col-sm-2 control-label">City</label>
								<div class="col-sm-10">
									<input type="text" name="city" class="form-control" id="city" value="Dhaka" placeholder="ex. city" maxlength="50">
																	</div>
							</div>
							<div class="form-group">
								<label for="zip" class="col-sm-2 control-label">Zip</label>
								<div class="col-sm-10">
									<input type="text" name="zip" class="form-control" id="zip" value="1230" placeholder="ex. zip" maxlength="25">
																	</div>
							</div>
							<div class="form-group">
								<label for="country" class="col-sm-2 control-label">Country</label>
								<div class="col-sm-10">
									<input type="text" name="country" class="form-control" id="country" value="Bangladesh" placeholder="ex. country" maxlength="50">
																	</div>
							</div>
							<div class="form-group">
								<div class="col-sm-offset-2 col-sm-10">
									<button type="submit" class="btn btn-info btn-flat">Update</button>
								</div>
							</div>
						</form>
					</div>
					<!-- /.tab-pane -->
					<div class="tab-pane" id="social_link">
						<form data-parsley-validate="" class="form-horizontal" action="http://ums.clustercoding.com/demo/admin/setting/social/1" method="post" novalidate="">
							<input type="hidden" name="_token" value="TyITdCmdMvfIeYp8TG2gjpyb9s4kmvyHXbnrHJ0A">
							<div class="form-group">
								<label for="facebook" class="col-sm-2 control-label">Facebook</label>
								<div class="col-sm-10">
									<input type="text" name="facebook" class="form-control" id="facebook" value="https://facebook.com/clustercoding" placeholder="ex. https://facebook.com/clustercoding" maxlength="250">
																	</div>
							</div>
							<div class="form-group">
								<label for="twitter" class="col-sm-2 control-label">Twitter</label>
								<div class="col-sm-10">
									<input type="text" name="twitter" class="form-control" id="twitter" value="https://twitter.com/cluster_coding" placeholder="ex. https://twitter.com/cluster_coding" maxlength="250">
																	</div>
							</div>
							<div class="form-group">
								<label for="google_plus" class="col-sm-2 control-label">Google Plus</label>
								<div class="col-sm-10">
									<input type="text" name="google_plus" class="form-control" id="google_plus" value="https://plus.google.com/+ClusterCoding" placeholder="ex. https://plus.google.com/+ClusterCoding" maxlength="250">
																	</div>
							</div>
							<div class="form-group">
								<label for="linkedin" class="col-sm-2 control-label">Linkedin</label>
								<div class="col-sm-10">
									<input type="text" name="linkedin" class="form-control" id="linkedin" value="https://www.linkedin.com/company/clustercoding/" placeholder="ex. https://www.linkedin.com/company/clustercoding/" maxlength="250">
																	</div>
							</div>
							<div class="form-group">
								<div class="col-sm-offset-2 col-sm-10">
									<button type="submit" class="btn btn-info btn-flat">Update</button>
								</div>
							</div>
						</form>
					</div>
					<!-- /.tab-pane -->
					<div class="tab-pane" id="home_page">
						<form data-parsley-validate="" class="form-horizontal" action="http://ums.clustercoding.com/demo/admin/setting/meta/1" method="post" enctype="multipart/form-data" novalidate="">
							<input type="hidden" name="_token" value="TyITdCmdMvfIeYp8TG2gjpyb9s4kmvyHXbnrHJ0A">

							<div class="form-group">
								<label for="home_page_content" class="col-sm-2 control-label">Home Page Content</label>
								<div class="col-sm-12">
									<textarea name="home_page_content" class="form-control summernote" id="home_page_content" required="">

</textarea>
							</div>

							<div class="form-group">
								<label for="featured_image" class="col-sm-2 control-label">Page Featured Image</label>
								<div class="col-sm-10">
									<input type="file" name="featured_image" class="form-control" id="featured_image">
																	</div>
							</div>

							<div class="bs-callout bs-callout-success">
							<h4>SEO Information</h4>
						</div>

							<div class="form-group">
								<label for="meta_title" class="col-sm-2 control-label">Meta Title</label>
								<div class="col-sm-10">
									<input type="text" name="meta_title" class="form-control" id="meta_title" value="Cluster Coding Blog" placeholder="ex. meta title" required="" maxlength="250">
																	</div>
							</div>
							<div class="form-group">
								<label for="meta_keywords" class="col-sm-2 control-label">Meta Keywords</label>
								<div class="col-sm-10">
									<input type="text" name="meta_keywords" class="form-control" id="meta_keywords" value="ClusterCoding Blog, Cluster, Coding, Blog" placeholder="ex. meta, keywords" required="" maxlength="250">
																	</div>
							</div>

							<div class="form-group">
								<label for="meta_description" class="col-sm-2 control-label">Meta Description</label>
								<div class="col-sm-10">
									<textarea name="meta_description" class="form-control" id="meta_description" placeholder="ex. meta description" required="" maxlength="350">ClusterCoding is among the pioneers in the Bangladesh to offer quality web services to medium and large sized businesses to compete in today’s digital world. We possess the experience and expertise to help web entrepreneurs reach their customers across the digital space.</textarea>
																	</div>
							</div>
							<div class="form-group">
								<div class="col-sm-offset-2 col-sm-10">
									<button type="submit" class="btn btn-info btn-flat">Update</button>
								</div>
							</div>
						</form>
					</div>
					<!-- /.tab-pane -->
					<div class="tab-pane" id="gallery_page_meta">
						<form data-parsley-validate="" class="form-horizontal" action="http://ums.clustercoding.com/demo/admin/setting/gallery-meta/1" method="post" novalidate="">
							<input type="hidden" name="_token" value="TyITdCmdMvfIeYp8TG2gjpyb9s4kmvyHXbnrHJ0A">
							<div class="form-group">
								<label for="gallery_meta_title" class="col-sm-2 control-label">Meta Title</label>
								<div class="col-sm-10">
									<input type="text" name="gallery_meta_title" class="form-control" id="gallery_meta_title" value="Cluster Coding Blog" placeholder="ex. meta title" required="" maxlength="250">
																	</div>
							</div>
							<div class="form-group">
								<label for="gallery_meta_keywords" class="col-sm-2 control-label">Meta Keywords</label>
								<div class="col-sm-10">
									<input type="text" name="gallery_meta_keywords" class="form-control" id="gallery_meta_keywords" value="ClusterCoding Blog, Cluster, Coding, Blog" placeholder="ex. meta, keywords" required="" maxlength="250">
																	</div>
							</div>

							<div class="form-group">
								<label for="gallery_meta_description" class="col-sm-2 control-label">Meta Description</label>
								<div class="col-sm-10">
									<textarea name="gallery_meta_description" class="form-control" id="gallery_meta_description" placeholder="ex. meta description" required="" maxlength="350">ClusterCoding is among the pioneers in the Bangladesh to offer quality web services to medium and large sized businesses to compete in today’s digital world. We possess the experience and expertise to help web entrepreneurs reach their customers across the digital space.</textarea>
																	</div>
							</div>
							<div class="form-group">
								<div class="col-sm-offset-2 col-sm-10">
									<button type="submit" class="btn btn-info btn-flat">Update</button>
								</div>
							</div>
						</form>
					</div>
					<!-- /.tab-pane -->
				</div>
				<!-- /.tab-content -->
			</div>
			<!-- /.nav-tabs-custom -->
		</div>
		<!-- /.col -->
	</div>
	<!-- /.row -->

</section>
<!-- /.content -->