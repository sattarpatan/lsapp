 <!-- Style -->
  <style type="text/css">
.modal-title {
	font-weight: bold;
}
.bg-grey{
	background-color: #BDBDBD;
}
.users-list>li {
	width: 10%;
}
</style>
  <!-- /.style -->


      <!-- Page header -->
<section class="content-header">
	<h1>
		DASHBOARD
	</h1>
	<ol class="breadcrumb">
		<li><a href="http://ums.clustercoding.com/demo/admin/dashboard"><i class="fa fa-home active"></i> Dashboard</a></li>
	</ol>
</section>
<!-- /.page header -->

<!-- Main content -->
<section class="content">
	<div class="row">
		<div class="col-lg-3 col-xs-6">
			<!-- small box -->
			<div class="small-box bg-grey">
				<div class="inner">
					<h3>18</h3>

					<p>USER</p>
				</div>
				<div class="icon">
					<i class="fa fa-users"></i>
				</div>
				<a href="users.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
			</div>
		</div>
		<!-- ./col -->
		<div class="col-lg-3 col-xs-6">
			<!-- small box -->
			<div class="small-box bg-grey">
				<div class="inner">
					<h3>97</h3>

					<p>SUBSCRIBER</p>
				</div>
				<div class="icon">
					<i class="fa fa-envelope"></i>
				</div>
				<a href="subscribers.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
			</div>
		</div>
		<!-- ./col -->
		<div class="col-lg-3 col-xs-6">
			<!-- small box -->
			<div class="small-box bg-grey">
				<div class="inner">
					<h3>7</h3>

					<p>PAGE</p>
				</div>
				<div class="icon">
					<i class="fa fa-file"></i>
				</div>
				<a href="pages.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
			</div>
		</div>
		<!-- ./col -->
		<div class="col-lg-3 col-xs-6">
			<!-- small box -->
			<div class="small-box bg-grey">
				<div class="inner">
					<h3>15</h3>

					<p>GALLERY</p>
				</div>
				<div class="icon">
					<i class="fa fa-image"></i>
				</div>
				<a href="galleries.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
			</div>
		</div>
		<!-- ./col -->
	</div>

	<div class="row">
		<div class="col-md-12">
			<!-- USERS LIST -->
			<div class="box">
				<div class="box-header with-border">
					<h3 class="box-title">Recent Users</h3>
				</div>
				<!-- /.box-header -->
				<div class="box-body no-padding">
					<ul class="users-list clearfix">
												<li>
														<img class="img-responsive" alt="alo@gmail.com" src="https://www.gravatar.com/avatar/076d1529ced39055b2426583854edefc?s=80&amp;d=mm&amp;r=g" width="128px">
														<a class="users-list-name user-view-button" data-id="35" role="button" tabindex="0">alo@gmail.com</a>
							<span class="users-list-date">22 November 2018</span>
						</li>
												<li>
														<img class="img-responsive" alt="jalaj" src="https://www.gravatar.com/avatar/5d379ea5d9411f76daffb4896b803919?s=80&amp;d=mm&amp;r=g" width="128px">
														<a class="users-list-name user-view-button" data-id="34" role="button" tabindex="0">jalaj</a>
							<span class="users-list-date">16 November 2018</span>
						</li>
												<li>
														<img class="img-responsive" alt="Soh" src="https://www.gravatar.com/avatar/f914b413f31b5cd1bf971780ba928182?s=80&amp;d=mm&amp;r=g" width="128px">
														<a class="users-list-name user-view-button" data-id="33" role="button" tabindex="0">Soh</a>
							<span class="users-list-date">11 October 2018</span>
						</li>
												<li>
														<img class="img-responsive" alt="salamon" src="https://www.gravatar.com/avatar/f5a25b4f3d8b7848f38280040ca8f8dd?s=80&amp;d=mm&amp;r=g" width="128px">
														<a class="users-list-name user-view-button" data-id="31" role="button" tabindex="0">salamon</a>
							<span class="users-list-date">05 August 2018</span>
						</li>
												<li>
														<img class="img-responsive" alt="sonu" src="https://www.gravatar.com/avatar/242bf3ee43ae757ada9ca27bd7f96914?s=80&amp;d=mm&amp;r=g" width="128px">
														<a class="users-list-name user-view-button" data-id="30" role="button" tabindex="0">sonu</a>
							<span class="users-list-date">31 July 2018</span>
						</li>
												<li>
														<img class="img-responsive" alt="Ahmet" src="http://ums.clustercoding.com/demo/public/avatar/29.png" width="128px">
														<a class="users-list-name user-view-button" data-id="29" role="button" tabindex="0">Ahmet</a>
							<span class="users-list-date">24 July 2018</span>
						</li>
												<li>
														<img class="img-responsive" alt="ytyyty" src="https://www.gravatar.com/avatar/3322040001694566265b91d3155fd5a9?s=80&amp;d=mm&amp;r=g" width="128px">
														<a class="users-list-name user-view-button" data-id="25" role="button" tabindex="0">ytyyty</a>
							<span class="users-list-date">13 June 2018</span>
						</li>
												<li>
														<img class="img-responsive" alt="Laptop" src="https://www.gravatar.com/avatar/23463b99b62a72f26ed677cc556c44e8?s=80&amp;d=mm&amp;r=g" width="128px">
														<a class="users-list-name user-view-button" data-id="24" role="button" tabindex="0">Laptop</a>
							<span class="users-list-date">12 June 2018</span>
						</li>
												<li>
														<img class="img-responsive" alt="NovaChimp" src="https://www.gravatar.com/avatar/c30712eda6e60a2d09140bf0b9a0d2b8?s=80&amp;d=mm&amp;r=g" width="128px">
														<a class="users-list-name user-view-button" data-id="22" role="button" tabindex="0">NovaChimp</a>
							<span class="users-list-date">05 June 2018</span>
						</li>
												<li>
														<img class="img-responsive" alt="pathuvai rajan" src="https://www.gravatar.com/avatar/5d36eab393920369aa01d43a0d13c8c5?s=80&amp;d=mm&amp;r=g" width="128px">
														<a class="users-list-name user-view-button" data-id="21" role="button" tabindex="0">pathuvai rajan</a>
							<span class="users-list-date">02 June 2018</span>
						</li>
											</ul>
					<!-- /.users-list -->
				</div>
				<!-- /.box-body -->
				<div class="box-footer text-center">
					<a href="users.php" class="btn btn-sm btn-info btn-flat pull-right">View All</a>
				</div>
				<!-- /.box-footer -->
			</div>
			<!--/.box -->
		</div>

		
	</section>
	<!-- /.main content -->