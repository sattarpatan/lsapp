    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Employee Form
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Examples</a></li>
        <li class="active">User profile</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
 		
        <!-- /.col -->
        <div class="col-md-12">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#activity" data-toggle="tab">Add new role</a></li>
            </ul>
            <div class="tab-content">
              <div class="active tab-pane" id="activity">
                <!-- Post -->
                <div class="post">
                  <form method="post" name="add_roles" action="<?php echo base_url('roles/add');?>" class="form-horizontal">
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Role Name</label>

                    <div class="col-sm-10">
                      <input type="text" name="name" id="role_name" placeholder="Role Name" class="form-control" <?php echo set_value('role_name');?>>
                    </div>
                  </div>
				  
				  <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th class="bold"><?php echo 'Permission'; ?></th>
                                    <th class="text-center bold"><?php echo 'View'; ?></th>
                                    <th class="text-center bold"><?php echo 'View (Own)'; ?></th>
                                    <th class="text-center bold"><?php echo 'Create'; ?></th>
                                    <th class="text-center bold"><?php echo 'Edit'; ?></th>
                                    <th class="text-center text-danger bold"><?php echo 'Delete'; ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $conditions = get_permission_conditions();
                                foreach($permissions as $permission){
                                    $permission_condition = $conditions[$permission['shortname']];
                                    ?>
                                    <tr>
                                        <td>
                                         <?php echo $permission['shortname']; ?>
                                         </td>
                                         <td class="text-center">
                                            <?php if($permission_condition['view'] == true){
                                                $statement = '';
                                                if(isset($role)){
                                                    if(total_rows('tblrolepermissions',array('roleid'=>$role->roleid,'permissionid'=>$permission['permissionid'],'can_view'=>1)) > 0){
                                                        $statement = 'checked';
                                                    }

                                                if(total_rows('tblrolepermissions',array('roleid'=>$role->roleid,'permissionid'=>$permission['permissionid'],'can_view_own'=>1)) > 0){
                                                    $statement = 'disabled';
                                                }
                                                }
                                                ?>
                                                <?php if(isset($permission_condition['help'])){
                                                 echo '<i class="fa fa-question-circle text-danger" data-toggle="tooltip" data-title="'.$permission_condition['help'].'"></i>';
                                             }
                                             ?>
                                             <div class="checkbox">
                                                <input type="checkbox" data-can-view <?php echo $statement; ?> name="view[]" value="<?php echo $permission['permissionid']; ?>">
                                                <label></label>
                                            </div>
                                            <?php } ?>
                                        </td>
                                        <td class="text-center">
                                            <?php if($permission_condition['view_own'] == true){
                                               $statement = '';
                                               if(isset($role)){
                                                if(total_rows('tblrolepermissions',array('roleid'=>$role->roleid,'permissionid'=>$permission['permissionid'],'can_view_own'=>1)) > 0){
                                                    $statement = 'checked';
                                                }

                                                 if(total_rows('tblrolepermissions',array('roleid'=>$role->roleid,'permissionid'=>$permission['permissionid'],'can_view'=>1)) > 0){
                                                    $statement = 'disabled';
                                                }


                                            }
                                            ?>
                                            <div class="checkbox">
                                               <input type="checkbox" data-shortname="<?php echo $permission['shortname']; ?>" <?php echo $statement; ?> name="view_own[]" value="<?php echo $permission['permissionid']; ?>" data-can-view-own>
                                               <label></label>
                                           </div>
                                           <?php } else if($permission['shortname'] == 'customers'){
                                              echo '<i class="fa fa-question-circle mtop15" data-toggle="tooltip" data-title="'.'permission_customers_based_on_admins'.'"></i>';
                                          } else if($permission['shortname'] == 'projects'){
                                              echo '<i class="fa fa-question-circle mtop25" data-toggle="tooltip" data-title="'.'permission_projects_based_on_assignee'.'"></i>';
                                          } else if($permission['shortname'] == 'tasks'){
                                              echo '<i class="fa fa-question-circle mtop25" data-toggle="tooltip" data-title="'.'permission_tasks_based_on_assignee'.'"></i>';
                                          } else if($permission['shortname'] == 'payments'){
                                          echo '<i class="fa fa-question-circle mtop15" data-toggle="tooltip" data-title="'.'permission_payments_based_on_invoices'.'"></i>';
                                          } ?>
                                      </td>

                                        <td class="text-center">
                                            <?php if($permission_condition['create'] == true){
                                                $statement = '';
                                                if(isset($role)){
                                                    if(total_rows('tblrolepermissions',array('roleid'=>$role->roleid,'permissionid'=>$permission['permissionid'],'can_create'=>1)) > 0){
                                                        $statement = 'checked';
                                                    }
                                                }
                                                ?>
                                                <div class="checkbox">
                                                    <input type="checkbox" data-shortname="<?php echo $permission['shortname']; ?>" data-can-create <?php echo $statement; ?> name="create[]" value="<?php echo $permission['permissionid']; ?>">
                                                    <label></label>
                                                </div>
                                                <?php } ?>
                                            </td>
                                              <td class="text-center">
                                        <?php if($permission_condition['edit'] == true){
                                            $statement = '';
                                            if(isset($role)){
                                                if(total_rows('tblrolepermissions',array('roleid'=>$role->roleid,'permissionid'=>$permission['permissionid'],'can_edit'=>1)) > 0){
                                                    $statement = 'checked';
                                                }
                                            }
                                            ?>
                                            <div class="checkbox">
                                                <input type="checkbox" data-shortname="<?php echo $permission['shortname']; ?>" data-can-edit <?php echo $statement; ?> name="edit[]" value="<?php echo $permission['permissionid']; ?>">
                                                <label></label>
                                            </div>
                                            <?php } ?>
                                        </td>
                                            <td class="text-center">
                                                <?php if($permission_condition['delete'] == true){
                                                    $statement = '';
                                                    if(isset($role)){
                                                        if(total_rows('tblrolepermissions',array('roleid'=>$role->roleid,'permissionid'=>$permission['permissionid'],'can_delete'=>1)) > 0){
                                                            $statement = 'checked';
                                                        }
                                                    }
                                                    ?>
                                                    <div class="checkbox checkbox-danger">
                                                        <input type="checkbox" data-shortname="<?php echo $permission['shortname']; ?>" data-can-delete <?php echo $statement; ?> name="delete[]" value="<?php echo $permission['permissionid']; ?>">
                                                        <label></label>
                                                    </div>
                                                    <?php } ?>
                                                </td>
                                            </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                    <button type="submit" class="btn btn-info pull-right"><?php echo'submit'; ?></button>
                                    <?php echo form_close(); ?>
                                </div>
				  
                  
                  <!--<div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                      <button type="submit" class="btn btn-info btn-flat">Submit</button>
                    </div>
                  </div>-->
				  
                </form>
                </div>
 
              </div>
              <!-- /.tab-pane -->
              
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->