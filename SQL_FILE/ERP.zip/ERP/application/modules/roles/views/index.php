      <!-- Page header -->
<section class="content-header">
	<h1>Role Management</h1>
	<ol class="breadcrumb">
		<li><a href="http://ums.clustercoding.com/demo/admin/dashboard"><i class="fa fa-home"></i> Dashboard</a></li>
		<li class="active">Page</li>
	</ol>
</section>
<!-- /.page header -->
<!-- Main content -->
<section class="content">
	<div class="box">
		<div class="box-header with-border">
			<h3 class="box-title">Manage Roles</h3>

			<div class="box-tools">
				<a href="<?php echo site_url('roles/add'); ?>" type="button" class="btn btn-info btn-sm btn-flat add-button"><i class="fa fa-plus"></i> Add Page</a>
			</div>
		</div>
		<!-- /.box-header -->
		<div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Role Name</th>
                  <th>Created On</th>
                  <th>Modified On</th>
				  <th>Publication Status</th>
				  <th>Action</th>
                </tr>
                </thead>
                <tbody>                
				<?php foreach($tblroles as $roles){?>
				<tr>	
                  <td><?php echo $roles['name'];?></td>
                  <td><?php echo $roles['name'];?></td>
                  <td><?php echo $roles['name'];?></td>
                  <td><a href="<?php echo site_url('roles/status');?>" class="btn btn-warning btn-xs btn-flat btn-block"><i class="icon fa fa-arrow-up"></i> Unpublished</a></td>
				  <td>
				  <a href="<?php echo site_url('roles/view/'.$roles['roleid']);?>"><button class="btn btn-info btn-xs view-button"><i class="fa fa-eye"></i></button></a>
				  <a href="<?php echo site_url('roles/edit/'.$roles['roleid']);?>"><button class="btn btn-primary btn-xs edit-button"><i class="fa fa-edit"></i></button></a>
				  <a href="<?php echo site_url('roles/delete/'.$roles['roleid']);?>"id="delete-button"><button class="btn btn-danger btn-xs delete-button"><i class="fa fa-trash"></i></button></a></td>
                </tr>
                <?php } ?>                
                </tbody>
                <tfoot>
                <tr>
					<th>Role Name</th>
					<th>Created On</th>
					<th>Modified On</th>
					<th>Publication Status</th>
					<th>Action</th>
                </tr>
                </tfoot>
              </table>
            </div>
		<!-- /.box-body -->
		<div class="box-footer clearfix">
		</div>
	</div>
</section>
<!-- /.main content -->
<!-- add page modal -->
<div id="add-modal" class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title">
						<span class="fa-stack fa-sm">
							<i class="fa fa-square-o fa-stack-2x"></i>
							<i class="fa fa-plus fa-stack-1x"></i>
						</span>
						Add Page
					</h4>
				</div>
				<form role="form" id="page_add_form" method="post" enctype="multipart/form-data">
					<div class="modal-body">
						<div class="form-group">
							<label>Publication Status</label>
							<select class="form-control" name="publication_status" id="publication_status">
								<option selected disabled>Select One</option>
								<option value="1">Published</option>
								<option value="0">Unpublished</option>
							</select>
							<span class="text-danger" id="publication-status-error"></span>
						</div>
						<div class="form-group">
							<label>Publication Status</label>
							<select class="form-control" name="publication_status" id="publication_status">
								<option selected disabled>Select One</option>
								<option value="1">Published</option>
								<option value="0">Unpublished</option>
							</select>
							<span class="text-danger" id="publication-status-error"></span>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal">Close</button>
						<button type="button" class="btn btn-info btn-flat" id="store-button">Save changes</button>
					</div>
				</form>

			</div>
		</div>
	</div>
	<!-- /.add page modal -->
<script>
/** Add **/
	/* $(".add-button").click(function(){
		$('#add-modal').modal('show');
	}); */
	
jQuery(document).ready(function(){
  jQuery("#delete-button").click(function(){
    confirm("Are you sure you want to perform this action?");
  });
});	
</script>
